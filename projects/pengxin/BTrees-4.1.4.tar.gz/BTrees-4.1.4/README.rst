``BTrees``:  scalable persistent components
===========================================

This package contains a set of persistent object containers built around
a modified BTree data structure.  The trees are optimized for use inside
ZODB's "optimistic concurrency" paradigm, and include explicit resolution
of conflicts detected by that mechannism.

Please see the Sphinx documentation (``docs/index.rst``) for further
information.
